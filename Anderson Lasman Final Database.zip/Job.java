/**
* Sarah Lasman and Haley Anderson
* Job.java
*/

public class Job
{
  int jobId;
  String jobTitle;
  String industry;
  String description;
  int companyId;
  int managerId;
  char type;
  int numOpenSpots;
  int numApplicants;
  int stockOptions;
  float signingBonus;
  float salary;
  String payPeriod;
  float rate;
  String season;
  int r1, r2, r3, r4, r5;

  public Job()
  {

  }
}
