/**
* Sarah Lasman and Haley Anderson
* Manager.java
*/

public class Manager
{
  int managerId;
  String managerName;
  boolean hasExperience;
  int yearsAtCompany;
  int companyId;
}
